﻿.+: Goto statement target does not exist.
   at ..(IMethodDeclaration mD, IMethodBody mB, Boolean handleExpressionStack)
   at ..(IMethodDeclaration mD, IMethodBody mB)
   at ..(IMethodDeclaration value)
   at ..(IMethodDeclarationCollection methods)
   at ..(ITypeDeclaration value)
   at ..TranslateTypeDeclaration(ITypeDeclaration value, Boolean memberDeclarationList, Boolean methodDeclarationBody)
   at ..(ITypeDeclaration typeDeclaration, String sourceFile, ILanguageWriterConfiguration languageWriterConfiguration)
Namespace AlterEgo
End Namespace

