﻿Imports Microsoft.VisualBasic.Devices
Imports System.CodeDom.Compiler
Imports System.ComponentModel

Namespace AlterEgo.My
    <GeneratedCode("MyTemplate", "8.0.0.0"), EditorBrowsable(EditorBrowsableState.Never)> _
    Friend Class MyComputer
        Inherits Computer
    End Class
End Namespace

