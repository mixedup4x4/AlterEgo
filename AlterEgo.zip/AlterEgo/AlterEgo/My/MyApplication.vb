﻿Imports Microsoft.VisualBasic.ApplicationServices
Imports System.CodeDom.Compiler
Imports System.ComponentModel

Namespace AlterEgo.My
    <EditorBrowsable(EditorBrowsableState.Never), GeneratedCode("MyTemplate", "8.0.0.0")> _
    Friend Class MyApplication
        Inherits ConsoleApplicationBase
    End Class
End Namespace

