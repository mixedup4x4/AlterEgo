﻿' Assembly AlterEgo, Version 77.0.0.0

<Assembly: System.Reflection.AssemblyTitle("Alter Ego")>
<Assembly: System.Reflection.AssemblyTrademark("")>
<Assembly: System.Reflection.AssemblyDescription("Please wait while alter ego loads")>
<Assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows:=True)>
<Assembly: System.Reflection.AssemblyCompany("AJCC Consulting")>
<Assembly: System.Reflection.AssemblyCopyright("Copyright © AJCC Consulting")>
<Assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)>
<Assembly: System.Reflection.AssemblyFileVersion("77")>
<Assembly: System.Runtime.InteropServices.Guid("42be074e-bf4c-458a-b20d-e780f0c6646a")>
<Assembly: System.Runtime.InteropServices.ComVisible(False)>
<Assembly: System.Reflection.AssemblyProduct("AE")>

